# Periodismo de Datos UC3M
Notas sobre **Periodismo de Datos** en *UC3M*

+ Periodismo
+ Visualización
+ Datos

**URLS** Se componen de dos partes
+ Protocolo: https://
+ Dominio; *.com*, *.es*
+ Carpetas: las separadel dominio una barra https:// dominio / carpetas
